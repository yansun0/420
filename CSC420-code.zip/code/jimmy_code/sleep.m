function sleep(num)    
    tic;
    while toc < num;
    end
end